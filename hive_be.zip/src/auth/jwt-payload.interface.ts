
export interface JwtPayload {
  email: string;
  accountId?: string;
}